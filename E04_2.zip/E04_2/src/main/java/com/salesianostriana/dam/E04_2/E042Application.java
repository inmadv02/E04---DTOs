package com.salesianostriana.dam.E04_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E042Application {

	public static void main(String[] args) {
		SpringApplication.run(E042Application.class, args);
	}

}
