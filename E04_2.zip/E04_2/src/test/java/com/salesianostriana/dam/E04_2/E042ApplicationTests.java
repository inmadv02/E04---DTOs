package com.salesianostriana.dam.E04_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E042ApplicationTests {

	@Test
	void contextLoads() {
	}

}
