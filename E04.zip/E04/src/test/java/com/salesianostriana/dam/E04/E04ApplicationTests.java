package com.salesianostriana.dam.E04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
