package com.salesianostriana.dam.E04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E04Application {

	public static void main(String[] args) {
		SpringApplication.run(E04Application.class, args);
	}

}
